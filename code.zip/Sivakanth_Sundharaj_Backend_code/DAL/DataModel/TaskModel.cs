﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.DataModel
{
    public class TaskModel
    {
        public string TaskName { get; set; }
        public DateTime? TaskStartDate { get; set; }
        public DateTime? TaskEndDate { get; set; }
        public int MemberId { get; set; }
        public string AllocationPercentage { get; set; }
        public int AssignedBy { get; set; }
        public string Deliverable { get; set; }
    }
}
