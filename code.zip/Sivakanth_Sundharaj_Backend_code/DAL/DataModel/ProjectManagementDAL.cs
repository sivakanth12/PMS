﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DAL.DataModel
{
    public class ProjectManagementDAL
    {
        ProjectManagementContext pme = new ProjectManagementContext();
        public void AddMember(MemberModel member)
        {
            pme.Member.Add(new Member()
            {
                MemberName = member.MemberName,
                YearOfExperience = member.YearOfExperience ,
                Skillset = member.Skillset,
                AdditionalDescription = member.AdditionalDescription
            }) ;
            pme.SaveChanges();
        }

        public IEnumerable<Member> FetchAllTeamMember()
        {
            return pme.Member;
        }

        public void AssignTask(TaskModel task)
        {
            pme.Task.Add(
                new Task()
                {
                    TaskName = task.TaskName,
                    TaskStartDate = task.TaskStartDate,
                    TaskEndDate = task.TaskEndDate,
                    MemberId = task.MemberId,
                    AllocationPercentage = task.AllocationPercentage,
                    AssignedBy = task.AssignedBy,
                    ProjectId = 2,
                    Deliverable = task.Deliverable,
                });
            pme.SaveChanges();
        }

        public IEnumerable<Task> ViewTask(int assignedBy)
        {
            return pme.Task.ToList().Where(a => a.AssignedBy == assignedBy);
        }

        public void UpdatePercentage(int id, string value)
        {
            var entity = pme.Task.FirstOrDefault(a => a.TaskId == id);
            entity.AllocationPercentage = value;
            pme.SaveChanges();
        }
    }
}

