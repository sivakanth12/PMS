﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.DataModel
{
    public class MemberModel
    {
        public string MemberName { get; set; }
        public string YearOfExperience { get; set; }
        public string Skillset { get; set; }
        public string AdditionalDescription { get; set; }
    }
}
