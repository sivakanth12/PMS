﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DAL.Models
{
    public partial class Task
    {
        public int TaskId { get; set; }
        public string TaskName { get; set; }
        public DateTime? TaskStartDate { get; set; }
        public DateTime? TaskEndDate { get; set; }
        public int MemberId { get; set; }
        public string AllocationPercentage { get; set; }
        public int AssignedBy { get; set; }
        public int? ProjectId { get; set; }
        public string Deliverable { get; set; }

        public virtual Member Member { get; set; }
        public virtual Project Project { get; set; }
    }
}
