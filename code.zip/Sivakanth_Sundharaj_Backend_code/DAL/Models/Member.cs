﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DAL.Models
{
    public partial class Member
    {
        public Member()
        {
            Task = new HashSet<Task>();
        }

        public int MemberId { get; set; }
        public string MemberName { get; set; }
        public string YearOfExperience { get; set; }
        public string Skillset { get; set; }
        public string AdditionalDescription { get; set; }

        public virtual ICollection<Task> Task { get; set; }
    }
}
