﻿using DAL.DataModel;
using DAL.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProjectManagementSystem.Controllers
{
    //[Route("api/[controller]")]
    //[Route("[controller]")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectManagementController : ControllerBase
    {
        private readonly ILogger<ProjectManagementController> _logger;

        public ProjectManagementController(ILogger<ProjectManagementController> logger)
        {
            _logger = logger;
        }

        ProjectManagementDAL project = new ProjectManagementDAL();


        // GET: api/<ProjectManagementController>
        [HttpGet]
        public IEnumerable<Member> Get()
        {
            return project.FetchAllTeamMember();
        }

        // GET api/<ProjectManagementController>/5
        [HttpGet("{id}")]
        public IEnumerable<Task> Get(int id)
        {
            return project.ViewTask(id);
        }

        // POST api/<ProjectManagementController>
        [HttpPost("AddMember")]
        public void Post([FromBody] MemberModel value)
        {
            project.AddMember(value);
        }

        // POST api/<ProjectManagementController>
        [HttpPost("AssignTask")]
        public void Post([FromBody] TaskModel value)
        {
            project.AssignTask(value);
        }

        // PUT api/<ProjectManagementController>/5
        [HttpPut("{id}")]
        public void Put(int id, string value)
        {
            project.UpdatePercentage(id,value);
        }
    }
}
